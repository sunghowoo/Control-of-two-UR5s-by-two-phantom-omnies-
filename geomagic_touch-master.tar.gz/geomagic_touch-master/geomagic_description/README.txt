
Cloned from this source
https://github.com/fsuarez6/phantom_omni
and modified to work with the model of 
https://github.com/danepowell/omni_description