#!/usr/bin/env python
import time
# import roslib; roslib.load_manifest('ur_driver')
import rospy
import actionlib
from control_msgs.msg import *
from trajectory_msgs.msg import *
from std_msgs.msg import Float64
from geometry_msgs import Vector3
from ur_kinematics import Kinematics
import math
from sensor_msgs.msg import JointState # To receive the current state


def callback():

   pub = rospy.Publisher('force_feedback', Vector3, queue_size=10)
   rospy.init_node('callback', anonymous=True)
   rate = rospy.Rate(10)

   while not rospy.is_shutdown():
           #hello_st = [1 , 1, 1, 1, 1, 1, True]
           pub.publish(hello_st)
           rate.sleep()

if __name__ == '__main__':
 	try:
		talker()
	except rospy.ROSInterruptException:
		pass


