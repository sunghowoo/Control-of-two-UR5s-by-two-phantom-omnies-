#!/usr/bin/env python
import time
# import roslib; roslib.load_manifest('ur_driver')
import rospy
import actionlib
from control_msgs.msg import *
from trajectory_msgs.msg import *
from std_msgs.msg import Float64
from sensor_msgs.msg import JointState # To receive the current state

def callback(msg):
 print msg.position[0]
rospy.init_node('topic_subscriber')
sub = rospy.Subscriber('/Geomagic/joint_states',JointState,callback)
rospy.spin()

def talker():
 pub = rospy.Publisher('/rrbot/joint1_position_controller/command', Float64, queue_size=10)
rospy.init_node('arm_talker', anonymous=True)
rate = rospy.Rate(10) # 10hz

while not rospy.is_shutdown():
 pos == 0.5 #msg.position[0] 
rospy.loginfo(pos) 
pub.publish(pos) 
rate.sleep()
if __name__ == '__main__': 
 try: 
  talker() 
 except rospy.ROSInterruptException: 
  pass
