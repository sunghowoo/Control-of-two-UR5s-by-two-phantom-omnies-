#!/usr/bin/python

import rospy 
from gazebo_msgs.msg import LinkStates
from geometry_msgs.msg import PoseStamped

class Topic(object):
    def __init__(self, my_pub):
      self._pub = my_pub

    def call (self, pt):
      u5pos = pt.pose[8]
      u5pos_name = pt.name[8]
      
      posest_msg = PoseStamped()
      posest_msg.pose = u5pos
      
      self._pub.publish(posest_msg)
      #rospy.loginfo('pose:{}'.format(u5pos))

def main():     
    rospy.init_node('pose_topic_node2') 
    my_pub = rospy.Publisher('/pose2_topic', PoseStamped, queue_size=10) 
    to = Topic(my_pub)
    rospy.Subscriber("/gazebo/link_states", LinkStates, to.call)
    rospy.spin()

if __name__ == '__main__':
    main()
