#!/usr/bin/env python
# THIS SCRIPT WAS JUST TO TEST STUFF AND SHOULD NOT  BE USED ANY MORE
import rospy
import math
from sensor_msgs.msg import JointState
from geomagic_control.msg import OmniFeedback
import tf
from geometry_msgs.msg import Pose, PoseStamped, Point, Quaternion
from std_msgs.msg import Header
from trajectory_msgs.msg import JointTrajectoryPoint
from control_msgs.msg import JointTrajectoryControllerState
from std_msgs.msg import Float32MultiArray
import time

def PS(origin,position=[0,0,0],orientation=[0,0,0,1]):
    """
        Creates a PoseStamped()
        
        :param origin: frame id
        :type: origin: str
        :param position: position (default [0,0,0])
        :type: position: list
        :param oriention: orientation (default [0,0,0,1])
        :type: orientation: list
        :return: the created PoseStamped()
        :rtype: PoseStamped
    """
    h=Header()
    h.frame_id=origin
    h.stamp=rospy.Time().now()
    
    p=Pose()
    if type(position) == Point:
        p.position = position
    else:
        p.position=Point(*position)
    if type(orientation) == Quaternion:
        p.orientation = orientation 
    elif len(orientation) == 4:
        p.orientation=Quaternion(*orientation)
    elif len(orientation) == 3:
        p.orientation = Quaternion(*tf.transformations.quaternion_from_euler(*orientation))
    else:
        p.orientation = Quaternion(0,0,0,1)
    return PoseStamped(h,p)
class GeomagicInterface:
    def __init__(self):
#         self.listener = tf.TransformListener()
        self.of = OmniFeedback()
        self.of.lock = [False for i in xrange(3)]
        self.pub = rospy.Publisher("Geomagic1/force_feedback",OmniFeedback,queue_size=1)
        # self.sub = rospy.Subscriber("Geomagic/end_effector_pose",JointState,self.callback, queue_size=1)
        self.lock = 0.0
       #self.sub = rospy.Subscriber("Geomagic1/joint_states",JointState,self.callback, queue_size=1) # end effector
        self.sub = rospy.Subscriber("pose2_topic",PoseStamped,self.callback, queue_size=1)
    
    #def call(self,unr):  
     #   global ur5x 
      #  global ur5y
	   # global ur5z
        #ur5x = unr.actual.positions[0]
        #ur5y = unr.actual.positions[1]
	    #ur5z = unr.actual.positions[2]
        #rospy.loginfo('force xu:{}'.format(pan))
    
    def callback(self,js):
        
        global ur5x
        global ur5y
      	global ur5z

        global diffx2 #zone 2
        global diffy2 #zone2
        global dist
        
        ur5y = js.pose.position.x
        ur5x = js.pose.position.y
	ur5z = js.pose.position.z

        diffx2 = abs(abs(ur5x) - 0)    #
        diffy2 = abs(ur5y) - 0.125 #
        dist = math.sqrt((diffx2*diffx2)+(diffy2*diffy2))

        self.of.lock = [False,False,False]
     	self.pub.publish(self.of) 

       # if dist < 0.05 :
       #   rospy.loginfo(' the postion of end effector is in the zone 2') 
      #  else :
      #    rospy.loginfo('Touched the box') 

        if ur5x > -0.6 and ur5x < -0.22 and ur5y < 0.25 and ur5y > 0.02 and ur5z < 1.8 : #zone 1

          self.of.force.x = -(ur5x+0.4)*7
          self.of.force.z = -(ur5y-0.125)*15
          self.of.force.y =  (ur5y-0.125)*7
           
        elif ur5x > -0.18 and ur5x < 0.18 and ur5y < 0.25 and ur5y > 0.02 and ur5z < 1.8 : # zone 2

          self.of.force.x = -(ur5x)*7
          self.of.force.z = -(ur5y-0.125)*15
          self.of.force.y =  (ur5y-0.125)*7      
          

        elif ur5x > 0.22 and ur5x < 0.6 and ur5y < 0.25 and ur5y > 0.02 and ur5z < 1.8 : # zone 3

          self.of.force.x = -(ur5x-0.4)*7
          self.of.force.z = -(ur5y-0.125)*15
          self.of.force.y =  (ur5y-0.125)*7
        elif ur5x > -0.6 and ur5x < -0.22 and ur5y < -0.02 and ur5y > -0.25 and ur5z < 1.8 : #zone 4
          self.of.force.x = -(ur5x+0.4)*7
          self.of.force.z = -(ur5y+0.125)*15
	  self.of.force.y =  (ur5y+0.125)*7
        elif ur5x > -0.18 and ur5x < 0.18 and ur5y < -0.02 and ur5y > -0.25 and ur5z < 1.8 : #zone 5
          self.of.force.x = -(ur5x)*7
          self.of.force.z = -(ur5y+0.125)*15
 	  self.of.force.y =  (ur5y+0.125)*7
        elif ur5x > 0.22 and ur5x < 0.6 and ur5y < -0.02 and ur5y > -0.25 and ur5z < 1.8 : # zone 6
          self.of.force.x = -(ur5x-0.4)*7
          self.of.force.z = -(ur5y+0.125)*15
	  self.of.force.y =  (ur5y+0.125)*7
        else : 
          self.of.force.x = 0
          self.of.force.z = 0
          self.of.force.y = 0

      


	 
        #rospy.loginfo('ur5x:{},ur5y:{},ur5z:{}'.format(ur5x,ur5y,ur5z))
        rospy.loginfo('distance:{}'.format(dist))
       # rospy.loginfo('force x:{}, force y:{}'.format(self.of.force.x,self.of.force.z))
	#rospy.loginfo('force z:{}, force zo:{},force zu:{}'.format(self.of.force.z,elbow,elbow1))
        
#     def start(self):
#         while not rospy.is_shutdown():
#             x = self.getPose("tip", "base").pose.position.x
#             print self.of.force.x
#             self.pub.publish(self.of)
#             rospy.sleep(0.1)

#     def getPose(self,target,source,timeout=1):
#         now = rospy.Time.now()
#         end = rospy.Time.now()+rospy.Duration(timeout)
#         while not rospy.is_shutdown() and now < end:
#             now = rospy.Time.now()
#             try:
#                 (trans,rot) = self.listener.lookupTransform(source,target, rospy.Time(0))
#                 return PS(source,trans,rot)
#             except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
#                 rospy.sleep(0.01)
#                 continue
#         raise Exception,"Transform %s -> %s never appeared"%(target,source)
#         return None
        
if __name__ == '__main__':
    
    rospy.init_node("geomagic1_touch_dof_locker")
    gi = GeomagicInterface()
    
    
    


    rospy.spin()
