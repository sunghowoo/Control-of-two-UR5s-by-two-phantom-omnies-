#!/usr/bin/python

import rospy 
from geometry_msgs.msg import PoseStamped

rospy.init_node('pose_topic_node1') 
my_pub = rospy.Publisher('/pose1_topic', PoseStamped, queue_size=10) 
posestamped_msg = PoseStamped()

rate = rospy.Rate(1)

while not rospy.is_shutdown():
	my_pub.publish(posestamped_msg)
	rate.sleep()

