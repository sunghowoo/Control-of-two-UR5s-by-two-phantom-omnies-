#!/usr/bin/python
#
# Send joint values to UR5 using messages
#
import time
from trajectory_msgs.msg import JointTrajectory
from std_msgs.msg import Header
from trajectory_msgs.msg import JointTrajectoryPoint
from control_msgs.msg import JointTrajectoryControllerState
from std_msgs.msg import Float32MultiArray
import rospy
import actionlib
import sys, select, termios, tty 
import numpy as np
from sensor_msgs.msg import JointState
reload(sys) 
sys.setdefaultencoding("UTF-8")
from ur_kinematics import Kinematics
from geometry_msgs.msg import PoseStamped
from geometry_msgs.msg import Pose
import math

def Call():
    rospy.init_node('Forward', anonymous=True, disable_signals=True)
    # setup pose topic subscriptio
    rospy.Subscriber("arm_controller/state",JointTrajectoryControllerState, main, queue_size=1)
    rospy.spin()

def main(data):
    ur_status = data
    # Create the topic message
    posest = PoseStamped()
    posest.header = Header()
    posest.header.stamp = rospy.Time.now()
    pose_current = ur_status.actual.positions#positions of U5
    rate = rospy.Rate(125) # 125hz = 0.08s

    # Initilise UR5 position
    kin = Kinematics('ur5')
    pose_xyz = kin.forward(pose_current) # Convert the current joints status to xyz
    current_xyz = pose_xyz[0:3,3:4]
    

    pub = rospy.Publisher('/pose1_topic',PoseStamped,queue_size=1)
    posest.pose = Pose()
    #posest.pose.position = Position()
    posest.pose.position.x = current_xyz[0]
    posest.pose.position.y = current_xyz[1]
    posest.pose.position.z = current_xyz[2]+1
    pub.publish(posest)
    rospy.loginfo(posest)
    rate.sleep()

if __name__ == '__main__':
    try:
        Call()
    except rospy.ROSInterruptException:
        print ("Program interrupted before completion")
