#UR5 twins for summer internship
---
## Overview
cd $HOME/catkin_ws/src
Move universal_robot folder into your src folder
cd $HOME/catkin_ws
# checking dependencies (again: replace '$ROS_DISTRO' with the ROS version you are using)
rosdep update
rosdep install --rosdistro kinetic --ignore-src --from-paths src

#building
catkin_make

#Launch simulation
roslaunch summer_gazebo summer_twin.launch
#Teleop keyboard#
rosrun summer_gazebo gazebo_teleop_key_xyz.py

        



